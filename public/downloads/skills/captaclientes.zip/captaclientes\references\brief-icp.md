# Brief ICP — Definir el cliente ideal

Objetivo: en pocas preguntas, saber a quién buscar. Si el usuario responde corto, sigue; no interrogues de más. Si algo falta, propón un valor tentativo y pide confirmación.

## Preguntas (haz las que falten, no todas si ya las sabes)

1. **¿Qué vendes exactamente?** Producto/servicio y el problema que resuelve.
2. **¿A quién se lo vendes?**
   - B2B: tipo de empresa (industria, tamaño) + cargo de quien decide/compra.
   - B2C: tipo de persona (perfil, momento de vida, interés).
3. **¿Ticket aproximado?** (precio o rango). Define cuánto esfuerzo justifica cada lead.
4. **¿Zona geográfica?** Local, nacional o global/online. Si es local, **acota el nivel**:
   - Ciudad completa (ej. "Santiago").
   - **Comunas/barrios específicos** (ej. "solo Providencia, Las Condes, Ñuñoa") — la skill filtra por esa lista.
   - Radio aproximado desde un punto (ej. "5 km de [dirección]"). Nota: la skill no calcula km exactos; lo traduce a las **comunas que caen en ese radio** y filtra por ellas. Pide al usuario que confirme la lista de comunas.
5. **¿Canal de contacto preferido?** Email, LinkedIn, Instagram/DM, teléfono, WhatsApp.
6. **¿Ejemplos de clientes ideales?** 1–3 clientes actuales que amarías clonar (o competidores cuyos clientes querrías).
7. **¿Anti-cliente?** A quién NO quieres (presupuesto bajo, mal fit, te hacen perder tiempo).
8. **¿Señal de compra observable?** Algo público que indique que necesitan lo que vendes (ej. "acaban de abrir", "contratando", "web anticuada", "ronda de inversión").
9. **¿Clientes actuales o exclusiones?** Empresas/personas que YA son clientes, o con las que ya hablaste, para no volver a contactarlas. (Si tiene una lista o CRM, pedir que la pegue para excluir.)
10. **¿Cuántos prospectos quieres?** Volumen objetivo de esta tanda (ej. 10, 20). Define cuánto buscar.

## Mínimo para avanzar a la Fase 2
- Qué vende + A quién + Zona + Canal.
- (Las preguntas 9 y 10 son recomendadas pero no bloquean: si no hay lista de exclusión, asume que no hay clientes previos; si no hay volumen, apunta a ~10.)

## Salida de esta fase
Un resumen de 4–6 líneas del ICP confirmado, por ejemplo:

> **ICP**: Agencias de marketing de 5–20 personas en Chile que aún no ofrecen servicios de IA. Decisor: fundador/director. Ticket ~$1.500/mes. Canal: LinkedIn + email. Señal: publican vacantes de marketing o tienen web sin mención de IA. Anti-cliente: freelancers solos y empresas <2 años.

Confirma este resumen con el usuario antes de buscar.
