# Playbook de outreach

Objetivo: un primer mensaje 1-a-1 por prospecto que consiga **respuesta**, no una venta a la primera. Cada mensaje se apoya en la **razón de fit** específica del prospecto.

**Obligatorio**: después de redactar, pasa todos los mensajes por la skill `humanizer` (sus 24 patrones) para que no suenen a IA.

---

## Anatomía de un buen primer mensaje

1. **Gancho personalizado** (1 línea): algo real y específico del prospecto (su lanzamiento, su vacante, su web, una reseña). Demuestra que NO es masivo.
2. **Puente al problema** (1 línea): conecta ese detalle con el dolor que resuelves.
3. **Valor concreto** (1 línea): qué resultado tangible ofreces, sin jerga.
4. **CTA suave** (1 línea): una pregunta fácil de responder ("¿tiene sentido que te cuente cómo?", "¿te paso un ejemplo de 2 min?"). Nunca "agenda una demo de 45 min" en frío.

Largo: cuanto más corto, mejor. Email frío < 90 palabras. DM/LinkedIn < 50 palabras.

---

## Plantillas por canal (esqueleto, luego humanizar)

### Email frío
```
Asunto: [referencia específica al prospecto]

Hola [nombre],

[gancho personalizado real].
[puente: por eso pensé en escribirte].
[valor concreto en 1 frase].

¿[pregunta CTA suave]?

[firma con nombre + 1 línea de credibilidad]
```

### Solicitud de conexión LinkedIn (nota corta)
```
Hola [nombre], vi [detalle específico]. Trabajo con [tipo de cliente] en [resultado].
Me gustaría conectar y, si tiene sentido, compartirte algo útil. Saludos, [nombre].
```

### DM (Instagram / LinkedIn ya conectado)
```
Hola [nombre], [gancho real]. [valor en 1 frase]. ¿[pregunta corta]?
```
(Sin emojis por defecto. Si el negocio es informal/B2C y encaja con su tono, uno suave puede ir — pero `humanizer` penaliza los emojis decorativos, así que justifícalo.)

---

## Secuencia de seguimiento (2-3 toques)

La mayoría de las respuestas llegan en el 2º o 3er toque, no en el primero. Genera la secuencia completa por prospecto, cada toque con **ángulo distinto** (no "¿viste mi mensaje?"):

- **Toque 1 (día 0):** el primer mensaje (gancho personalizado + valor + CTA suave).
- **Toque 2 (día +3 a +5):** aporta algo nuevo — un ejemplo concreto, un mini-caso, o un recurso útil. Sin reproche. Ej: "Te dejo igual un ejemplo de cómo lo resolvimos para [caso parecido], por si te sirve."
- **Toque 3 (día +7 a +10):** cierre cordial que deja la puerta abierta. Ej: "Entiendo que quizás no es el momento. Si más adelante te hace sentido, acá estoy. Te deseo éxito con [algo específico de ellos]."

Reglas: cada toque suma valor, nunca presiona; si responden, se corta la secuencia; adapta el canal (email/LinkedIn/WhatsApp). Para secuencias de email más elaboradas puedes orquestar la skill `marketing:email-sequence`. **Todos los toques pasan por `humanizer`.**

## Reglas de oro
- **Una razón de fit por mensaje.** Si no puedes personalizar, no envíes.
- **Nada de plantilla obvia.** Si el mensaje sirve igual para 100 personas, está mal.
- **Sin promesas vacías** ("revolucionario", "el mejor"). humanizer las elimina.
- **Un solo CTA**, fácil de responder.
- **Seguimiento**: deja anotado en la lista cuándo y cómo hacer el 2º toque (3–5 días después, ángulo distinto).
- **Ético**: no spam masivo, respeta opt-out y políticas de la plataforma.
