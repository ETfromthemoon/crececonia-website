# Estructura de 9 secciones — Fórmula Crececonia

Estructura conversion-tested para landings B2B LATAM. Es la que usa crececonia.cl. Cada sección responde a una pregunta del lector y prepara la siguiente.

---

## 1. Hero (lo primero que ve)

**Responde:** "¿Qué hago aquí y para quién es esto?"

**Componentes**:
- Headline grande con 1 promesa concreta (no genérica)
- Subhead de 1-2 líneas con el "cómo" o el contraste
- 1 CTA principal (no varios)
- 3 señales de confianza inline (sin compromiso · respuesta rápida · si no es para ti, te lo digo)
- Fondo con atmósfera (dot pattern + orbe + paths animados — no foto stock)

**Headline frameworks** (elegir el que mejor calza con el brief):
- **Dolor-solución**: "Mejoramos los 3 procesos que te cuestan más dinero cada mes."
- **Promesa-mecanismo**: "Reducimos 50% el tiempo de [proceso] en 6 semanas."
- **Contraste**: "No te vendemos horas. Te entregamos sistemas que tu equipo usa."

**Nunca**:
- "La plataforma líder en X"
- "Revoluciona tu negocio con IA"
- Headlines de más de 12 palabras

---

## 2. Problema (validas que entiendes su dolor)

**Responde:** "¿Esto es para mí? ¿Conocen mi problema?"

**Componentes**:
- 3-4 estadísticas con sources reales (Gartner, McKinsey, Deloitte, Forrester)
- Cada stat con: número + descripción + source + año
- Layout: barras horizontales o cards minimal

**Reglas**:
- Stats VERIFICABLES (no inventar). Si el cliente no tiene fuente, no usar el número.
- Año de la fuente visible (no usar fuentes >3 años)
- Conectar el problema con el cliente: "Por eso 7 de cada 10 PyMEs..."

---

## 3. Caso de uso / Authority (te presentas)

**Responde:** "¿Quién está detrás de esto? ¿Por qué les voy a creer?"

**Componentes**:
- Foto del consultor o equipo (humana, no stock)
- 1-2 párrafos en primera persona del consultor
- 3 facts numerados (+30 proyectos / 7 industrias / 4 países)
- Email o LinkedIn de contacto directo
- Honestidad: "Si no veo caso claro para IA, te lo digo en la llamada"

**Reglas**:
- Primera persona, voz directa
- Mencionar fallos o limitaciones (genera confianza)
- Datos concretos

---

## 4. Cómo funciona (el proceso)

**Responde:** "¿Qué pasa si trabajo con ustedes? ¿Cómo es el flujo?"

**Componentes**:
- 3-5 pasos numerados
- Cada paso: título + descripción de 1-2 líneas + tiempo estimado
- Visual: timeline horizontal, cards apiladas, o numbers grandes

**Estructura ejemplo Crececonia**:
1. **Diagnóstico (30 min)** — llamada para entender procesos
2. **Auditoría (2 semanas)** — mapa con ROI y roadmap
3. **Implementación (6-8 semanas)** — sistema en producción
4. **Adopción (90 días)** — medición y ajustes

**Reglas**:
- Plazos REALES, no idealizados
- Lo que recibe el cliente en cada paso (entregable)
- Lo que se requiere de él (input)

---

## 5. Resultados (prueba social)

**Responde:** "¿Esto realmente funciona? ¿Hay evidencia?"

**Componentes**:
- 4-6 case cards con: sector + métrica + impacto + descripción + tamaño cliente + tiempo
- Filtro por sector opcional (si tienes 6+ cases)
- Progress bars o números grandes

**Reglas**:
- Casos REALES con permiso del cliente
- Métricas concretas: % de reducción, USD ahorrados, horas recuperadas
- Tiempo a resultado visible
- NO testimonios genéricos sin contexto

**Anti-pattern**:
- "Aumentamos su productividad" → cuánto, cómo se mide
- "Felices con el servicio" → qué resultado obtuvieron

---

## 6. Servicios / Inversión

**Responde:** "¿Cuánto cuesta esto?"

**Componentes**:
- 2-3 cards de servicio
- Cada card: nombre + descripción 1 línea + precio + features (5-6 bullets) + CTA
- 1 card destacada (la del medio normalmente)
- Línea de honestidad arriba ("Pago contra entregables · Sin contrato anual")

**Estructura Crececonia (3 tiers)**:
1. **Auditoría Express** (USD 500, 2 semanas) — diagnóstico + roadmap
2. **Implementación** (USD 1.200+, 6-8 semanas) — sistema en producción [DESTACADA]
3. **Implementación + 90 días** (USD 3.000+, 90 días) — con adopción medida

**Reglas**:
- Precio VISIBLE (no "consultar precio")
- Qué incluye cada tier (sin overlap)
- "Te llevas:" línea concreta al final de cada card
- CTAs específicas: "Empezar Auditoría" (no "Postular a")

---

## 7. Garantía (reduces el riesgo percibido)

**Responde:** "¿Qué pasa si no funciona?"

**Componentes**:
- Headline grande con la promesa central
- 3 pillars con icono + título + descripción

**Estructura Crececonia**:
- **Sin contrato anual** — cada fase cancelable
- **NDA incluido** — confidencialidad total
- **Pago contra entregables** — no facturamos horas

**Reglas**:
- Garantía REAL y verificable
- Sin letra chica oculta
- Concrete: "Si en semana 3 no se usa el sistema, lo iteramos sin costo"

---

## 8. FAQ (preguntas críticas que frenan la decisión)

**Responde:** "¿Pero qué pasa con...?"

**Componentes**:
- 8-12 preguntas estructuradas como objeciones reales
- Acordeón colapsable (1 abierto a la vez)
- Respuestas directas, no defensivas

**Categorías obligatorias** (al menos una de cada):
- **Setup**: "¿Necesito tener experiencia previa?" / "¿Mis datos están listos?"
- **Tiempo**: "¿Cuánto tarda en verse impacto?"
- **Tools**: "¿Qué herramientas usan?"
- **Geografía**: "¿Trabajan con [país]?"
- **No-fit**: "¿Qué pasa si dicen que no hay fit?"
- **Pricing**: "¿Cuánto cuesta realmente?"
- **Garantía**: "¿Qué pasa si no veo ROI?"

**Reglas**:
- Tono directo, no corporativo
- Respuestas con datos concretos
- Honestidad sobre limitaciones

---

## 9. CTA Final

**Responde:** "OK, ¿qué hago ahora?"

**Componentes**:
- Headline emocional con el dolor o promesa
- Subhead con la oferta del CTA
- 1 botón principal grande
- Señales de confianza (respuesta en X tiempo, NDA, sin compromiso)
- Línea de urgencia (cupos / cohorte / promoción temporal)

**Estructura Crececonia**:
- Headline: "Dinos qué proceso te quita el sueño."
- Sub: "Respondemos en menos de 2 horas hábiles. Si no vemos fit real, te lo decimos."
- Urgencia: "Cupos disponibles para [mes próximo] · Agenda hoy"
- CTA: "Recibir mi evaluación AI gratis"

**Reglas**:
- 1 sola acción (no varios CTAs compitiendo)
- Texto del botón en infinitivo: "Recibir", "Empezar", "Agendar"
- Repetir las señales de confianza del Hero

---

## Navbar y Footer

**Navbar** (sticky, transparente que se oscurece al scroll):
- Logo (link a `/`)
- Items: Problema · Proceso · Resultados · Inversión · FAQ · [Otras páginas]
- CTA secundario a la derecha

**Footer** (minimalista):
- Logo
- Repetir nav items + páginas legales (privacy si hay forms)
- Copyright con año dinámico
- Email de contacto

---

## Anti-patrones de estructura

1. **NO** poner pricing antes de generar deseo (después de Resultados)
2. **NO** olvidar el bloque Authority (gente compra a personas, no marcas)
3. **NO** poner FAQ antes de Servicios (mata el momentum)
4. **NO** terminar la página sin CTA final (deja al lector sin acción)
5. **NO** repetir el mismo CTA 5+ veces (el del Hero, uno mid-page en Resultados, y el Final son suficientes)
