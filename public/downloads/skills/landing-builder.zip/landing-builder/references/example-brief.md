# Ejemplo de Brief Completo — Crececonia.cl

Ejemplo real del brief que llevó a la landing crececonia.cl. Úsalo como template y referencia de calidad.

---

## 1. Empresa y producto

**Nombre**: Crece con IA (crececonia.cl)
**Empresa madre**: Strimo SPA
**Dueño**: Sergio Astudillo

**Qué hace**: Consultora de inteligencia artificial para empresas medianas en LATAM. Identifica, diseña e implementa automatizaciones con IA en procesos operativos. No vende software, vende implementación.

---

## 2. Cliente ideal

**Sector**: Servicios profesionales, manufactura, logística, retail multi-sucursal, distribución, construcción (B2B mixto)
**Tamaño**: 30-150 empleados (PyMEs)
**Geografía**: Chile primario, LATAM (México, Colombia, Argentina, Perú) y España
**Rol decisor**:
- CEO / Fundador (40% de los casos)
- Director de Operaciones / COO (35%)
- Gerente Comercial (15%)
- CTO / IT Manager (10%)

**Persona psicográfica**: Dueño/decisor que ya intentó "comprar IA" con plataformas genéricas y le faltó adopción. Tiene 2-3 procesos identificados pero no sabe por dónde empezar.

---

## 3. Dolor principal

**Síntoma observable**:
> "Sabemos que la IA puede ayudarnos, pero no sabemos QUÉ implementar primero ni cómo lograr que el equipo lo use."

**Costos asociados**:
- 3-5 personas full-time en tareas repetitivas (USD 6.000-12.000/mes en sueldos)
- Errores manuales que generan 10-15% retrabajo
- Decisiones lentas porque la info está dispersa
- Oportunidades de venta perdidas por seguimiento tardío

**Por qué no lo han resuelto solo**:
- ChatGPT/Copilot por su cuenta no se adopta (el equipo lo usa 1 vez y abandona)
- Agencias les cobran USD 20-30k por proyectos que no entregan adopción
- Consultores genéricos entregan PDFs sin implementación
- El IT interno no tiene tiempo ni expertise en IA específica

---

## 4. Oferta y precio

**Tres servicios con escalera de compromiso**:

### Servicio 1 — Auditoría Express (USD 500)
- Duración: 2 semanas
- Entregable: mapa de procesos candidatos + ROI estimado + roadmap priorizado
- Pago: 100% al firmar
- Garantía: si NPS final <7, refund 50%

### Servicio 2 — Implementación (USD 1.200+)
- Duración: 6-8 semanas
- Entregable: 1 proceso completamente automatizado con IA + capacitación equipo
- Pago: 50% al firmar + 50% al go-live
- Incluye: 30 días soporte post-lanzamiento

### Servicio 3 — Implementación + 90 días (USD 3.000+)
- Duración: 90 días totales (implementación + adopción asistida)
- Entregable: Servicio 2 + sesiones quincenales + dashboard adopción
- Pago: 40% al firmar + 30% al go-live + 30% a los 90 días
- Garantía: adopción medida >70% al día 90, o iteramos sin costo

---

## 5. Diferenciación (USP)

**Frase canónica**:
> "Una agencia te vende horas de implementación. Un consultor genérico te entrega un PDF. Nosotros instalamos el sistema y nos quedamos hasta que tu equipo lo use. Si en la semana 3 no se usa, no facturamos la fase de adopción."

**Pilares diferenciales**:
1. **Pago contra entregables**, no contra horas
2. **Sin contrato anual**, cada fase es cancelable
3. **NDA incluido** desde la primera entrevista
4. **Garantía de adopción** medible al día 90

---

## 6. Prueba social

**Stats canónicas**:
- +30 proyectos en producción
- 7 industrias
- 4 países

**Casos publicables** (con permiso del cliente):

1. **Construcción** (constructora ~120 empleados, Chile)
   - Métrica: -62% tiempo de cotización
   - Detalle: Presupuestos automáticos, de 3 días a medio día
   - Tiempo a resultado: 3 semanas

2. **Distribución** (~200 empleados)
   - Métrica: -85% errores en pedidos
   - Detalle: Validación automática contra inventario en tiempo real
   - Tiempo: mes 2 post go-live

3. **Servicios profesionales** (consultora ~35 empleados)
   - Métrica: -40% horas administrativas
   - Detalle: Automatización de reportes, 15h semanales recuperadas
   - Tiempo: 4 semanas

4. **Manufactura** (~80 empleados)
   - Métrica: -70% tiempo de respuesta RFQ
   - Detalle: Cotizaciones técnicas generadas con datos de producción
   - Tiempo: mes 1 post go-live

5. **Retail** (~50 empleados)
   - Métrica: +35% conversión de leads
   - Detalle: Atención 24/7 con calificación automática de prospectos
   - Tiempo: 6 semanas

6. **Logística** (~150 empleados)
   - Métrica: -28% costo por envío
   - Detalle: Optimización de rutas y asignación de transportistas
   - Tiempo: mes 3 post go-live

**Año de los casos**: 2024-2026 (proyectos completados, no proyecciones).

---

## 7. Urgencia / Limitación

**Limitante natural**: capacity del consultor (Sergio Astudillo individual + red de implementadores).

**Cupos visibles en landing**: "Cupos disponibles para junio 2026" (variable según mes)

**Urgencia secundaria** (en email/CTA Final):
- "Cada mes que pasa son ~USD 6.600 en horas-equipo perdidas en este proceso"
- "El equipo se desmoraliza si seguimos hablando de IA sin implementar"

**NO usar urgencia falsa** (descuentos por tiempo limitado en este pricing).

---

## 8. Voz de marca

**Tono**:
- Directo
- Honesto
- Técnico-comercial (no jerga corporativa)
- Latinoamericano (no neutro)

**Adjetivos a EVITAR**:
- Pretencioso ("expertos líderes")
- Vendedor ("oferta especial")
- Mágico ("revoluciona", "transforma")

**Frases canónicas que suenan a Sergio**:
- "Si no es para ti, te lo decimos."
- "Pagas contra entregables, no horas."
- "Si no se usa, no se factura."
- "No vendemos software, vendemos implementación."
- "Te entregamos un sistema, no un PDF."

**Referencias de voz**:
- **Basecamp**: claridad y oposición a normas de industria
- **Stripe**: precisión técnica + accesibilidad
- **Linear**: minimalismo + opinión fuerte

---

## Estrategia derivada del brief

**Headline propuestos (3 angles)**:

1. **Dolor-solución**:
   > "Mejoramos los 3 procesos que te cuestan más dinero cada mes con IA."

2. **Promesa-mecanismo**:
   > "En 6 semanas tienes IA implementada en el proceso que más tiempo te quita."

3. **Contraste**:
   > "No te vendemos horas. Te entregamos sistemas que tu equipo usa."

**Headline ganador**: Opción 1 (la actual en crececonia.cl).

**CTA principal**: "Recibir mi evaluación AI gratis" (lleva al modal Evaluación AI).

**Prueba social arriba del fold**: "+30 proyectos · 7 industrias · 4 países" en cards o inline.

---

## Aesthetic derivada del brief

**Dirección**: Editorial dark con acentos luxury (champagne sobre obsidian).

**Por qué**:
- Cliente B2B premium percibe valor con estética refinada (no startup-ish)
- Diferencia visualmente de competidores típicos (gradientes SaaS azul/morado)
- Comunica seriedad sin parecer corporativo aburrido

**Paleta**:
- Obsidian #0A0A0B (fondo)
- Champagne #D9B36A (acento)
- Bone #F5F5F4 (texto primario)
- Ash #A8A29E (texto secundario)

**Tipografía**:
- Display: Fraunces (serif moderno italic/normal)
- Body: Inter
- Mono: JetBrains Mono

---

## Lecciones de este brief

1. **Tres servicios funcionan mejor que uno** — escalera de compromiso (USD 500 → 1.200 → 3.000) deja entrar con bajo riesgo
2. **Garantía concreta** ("si no se usa, no se factura") es lo que más cierra ventas en B2B
3. **Honestidad explícita** ("si no es para ti, te lo decimos") genera más confianza que promesas
4. **Stats reales con sources** (Gartner, McKinsey con año) > stats inventados
5. **Voz en primera persona del consultor** (Sergio) > voz corporativa anónima
